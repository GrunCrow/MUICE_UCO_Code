This is an extract of the Berkely Dataset for edge detection [1].


[1] https://www2.eecs.berkeley.edu/Research/Projects/CS/vision/bsds/
